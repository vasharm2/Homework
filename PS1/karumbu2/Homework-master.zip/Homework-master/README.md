# Homework
Homework for students

You can do the Problem Sets in whatever language you wish. Templates will be provided for Java, C++, and Python! (WIP, coming soon)

### Make sure you follow the submission instructions located [here](https://github.com/CS196Illinois/Submissions/blob/master/README.md)